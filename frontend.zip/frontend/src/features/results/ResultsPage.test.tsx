import { screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { vi } from "vitest";
import { ResultsPage } from "./ResultsPage";
import { renderWithProviders } from "@/test/renderWithProviders";

vi.mock("@/services/api", () => ({
  api: {
    getResults: vi.fn(),
    downloadAllReports: vi.fn().mockResolvedValue(undefined),
  },
}));

import { api } from "@/services/api";

describe("ResultsPage", () => {
  beforeEach(() => {
    vi.mocked(api.getResults).mockResolvedValue([
      {
        resultId: 10,
        screeningId: 4,
        entityName: "Acme",
        queriedName: "Acme",
        status: "clear",
        matchScore: null,
        ofacSource: "OFAC",
        ofacProgram: "SDN",
        remarks: null,
        timestamp: "2026-06-20T00:00:00Z",
      },
    ]);
  });

  it("renders rows from api", async () => {
    renderWithProviders(<ResultsPage />);
    expect(await screen.findByText("Acme")).toBeInTheDocument();
  });

  it("triggers download all reports", async () => {
    renderWithProviders(<ResultsPage />);
    await waitFor(() => expect(screen.getByText("Acme")).toBeInTheDocument());
    await userEvent.click(screen.getByLabelText(/download all pdf/i));
    await waitFor(() => expect(api.downloadAllReports).toHaveBeenCalled());
  });
});
