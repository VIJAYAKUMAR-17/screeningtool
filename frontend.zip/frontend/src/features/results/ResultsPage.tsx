import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import PlayArrowOutlinedIcon from "@mui/icons-material/PlayArrowOutlined";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
  InputAdornment,
  Stack,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import { DataGrid, GridColDef } from "@mui/x-data-grid";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { useEffect, useMemo, useState } from "react";
import toast from "react-hot-toast";
import { PageTitle } from "@/components/common/PageTitle";
import { StatusChip } from "@/components/common/StatusChip";
import { api } from "@/services/api";
import { http } from "@/services/http";
import { RunRecord, ScreeningResult, Tier2ScreeningResult } from "@/types/api";
import FilterListOutlinedIcon from "@mui/icons-material/FilterListOutlined";
import { Tier2StructuredDetails } from "@/components/common/Tier2StructuredDetails";

type ResultRow = ScreeningResult & { id: number };

const vendorColumns: GridColDef<ResultRow>[] = [
  {
    field: "queriedName",
    headerName: "Name",
    flex: 1.2,
    minWidth: 200,
    renderCell: (params) => (
      <Stack direction="row" spacing={0.8} alignItems="center" sx={{ height: "100%" }}>
        <span>{params.value as string}</span>
        {params.row.resultType === "customer" && (
          <Tooltip title="Customer was also screened">
            <Chip label="Customer" size="small" color="info" variant="outlined" />
          </Tooltip>
        )}
      </Stack>
    ),
  },
  {
    field: "status",
    headerName: "Status",
    width: 160,
    renderCell: (params) => <StatusChip status={params.row.status} />,
  },
  {
    field: "matchScore",
    headerName: "Score",
    width: 100,
    valueFormatter: (value) => (typeof value === "number" ? `${value}%` : "-"),
  },
  {
    field: "matchedName",
    headerName: "Matched Entity",
    flex: 1,
    minWidth: 200,
    valueGetter: (_, row) => row.matchedName ?? "-",
  },
  {
    field: "ofacSource",
    headerName: "List",
    width: 100,
    valueGetter: (_, row) => row.ofacSource ?? "-",
  },
  {
    field: "matchType",
    headerName: "Match Type",
    width: 130,
    valueGetter: (_, row) => row.matchType ?? "-",
  },
];

function OutcomeSummary({ run }: { run: RunRecord }) {
  return (
    <Stack direction="row" spacing={0.5} alignItems="center">
      {run.flagged > 0 && (
        <Chip size="small" label={`${run.flagged} Flagged`} color="error" />
      )}
      {run.reviewNeeded > 0 && (
        <Chip size="small" label={`${run.reviewNeeded} Review`} color="warning" />
      )}
      {run.clear > 0 && (
        <Chip size="small" label={`${run.clear} Clear`} color="success" variant="outlined" />
      )}
      {run.flagged === 0 && run.reviewNeeded === 0 && run.clear === 0 && (
        <Typography variant="body2" color="text.secondary">-</Typography>
      )}
    </Stack>
  );
}

export function ResultsPage() {
  const { data: runs = [], isLoading } = useQuery({
    queryKey: ["results"],
    queryFn: api.getScreeningRuns,
  });

  const [search, setSearch] = useState("");
  const [selectedRun, setSelectedRun] = useState<RunRecord | null>(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    void queryClient.invalidateQueries({ queryKey: ["dashboard-stats"] });
    void queryClient.invalidateQueries({ queryKey: ["dashboard-charts"] });
  }, [queryClient, runs.length]);

  const { data: runDetails, isLoading: detailsLoading } = useQuery({
    queryKey: ["run-details", selectedRun?.runId],
    queryFn: () => api.getRunDetails(selectedRun!.runId),
    enabled: !!selectedRun,
  });

  const tier2Query = useQuery({
    queryKey: ["tier2-run", selectedRun?.runId],
    queryFn: async () => {
      const { data } = await http.get<Tier2ScreeningResult>(`/tier2/runs/${selectedRun!.runId}`);
      return data;
    },
    enabled: !!selectedRun,
    retry: false,
  });

  const runTier2Mutation = useMutation({
    mutationFn: async (runId: number) => {
      const { data } = await http.post<Tier2ScreeningResult>("/tier2/screen", { run_id: runId, include_adverse_media: true }, { timeout: 0 });
      return data;
    },
    onMutate: () => toast.loading("Tier 2 screening started", { id: "tier2" }),
    onSuccess: async (data) => {
      toast.success("Tier 2 screening completed", { id: "tier2" });
      queryClient.setQueryData(["tier2-run", selectedRun?.runId], data);
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["tier2-dashboard"] }),
        queryClient.invalidateQueries({ queryKey: ["dashboard-stats"] }),
        queryClient.invalidateQueries({ queryKey: ["dashboard-charts"] }),
      ]);
    },
    onError: (err: Error) => toast.error(err.message, { id: "tier2" }),
  });

  const filtered = useMemo(
    () =>
      runs.filter((r) =>
        r.customerName.toLowerCase().includes(search.toLowerCase()),
      ),
    [runs, search],
  );

  const downloadReport = async (runId: number, kind: "pdf" | "excel") => {
    const id = toast.loading(`Preparing ${kind.toUpperCase()}...`);
    try {
      await api.downloadReport(runId, kind);
      toast.success(`${kind.toUpperCase()} downloaded`, { id });
    } catch (err) {
      toast.error((err as Error).message, { id });
    }
  };

  const runColumns: GridColDef<RunRecord>[] = [
    { field: "runId", headerName: "Run #", width: 80 },
    { field: "customerName", headerName: "Customer", flex: 1, minWidth: 160 },
    { field: "vendorsScreened", headerName: "Vendors", width: 90, align: "center", headerAlign: "center" },
    {
      field: "outcomes",
      headerName: "Outcomes",
      flex: 1.2,
      minWidth: 220,
      sortable: false,
      renderCell: (params) => <OutcomeSummary run={params.row} />,
    },
    {
      field: "elapsedSeconds",
      headerName: "Duration",
      width: 100,
      valueFormatter: (value) => (typeof value === "number" ? `${value.toFixed(2)}s` : "-"),
    },
    {
      field: "startedAt",
      headerName: "Date",
      minWidth: 180,
      valueGetter: (_, row) => format(new Date(row.startedAt), "PPpp"),
    },
    {
      field: "actions",
      headerName: "",
      width: 60,
      sortable: false,
      filterable: false,
      renderCell: (params) => (
        <IconButton size="small" aria-label="view vendors" onClick={() => setSelectedRun(params.row)}>
          <VisibilityOutlinedIcon fontSize="small" />
        </IconButton>
      ),
    },
  ];

  const detailRows: ResultRow[] =
    runDetails?.results.map((r, idx) => ({ ...r, id: idx + 1 })) ?? [];

  return (
    <Stack spacing={2}>
      <PageTitle
        title="Screening History"
        subtitle="All past screening runs - click the eye icon to see Tier 1 and Tier 2 details."
      />

      <TextField
        fullWidth
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search by customer name..."
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <FilterListOutlinedIcon />
            </InputAdornment>
          ),
        }}
      />

      <Box sx={{ height: 600 }}>
        <DataGrid
          loading={isLoading}
          rows={filtered}
          columns={runColumns}
          getRowId={(row) => row.runId}
          pageSizeOptions={[10, 25, 50]}
          disableRowSelectionOnClick
        />
      </Box>

      <Dialog
        open={!!selectedRun}
        onClose={() => setSelectedRun(null)}
        fullWidth
        maxWidth="lg"
      >
        <DialogTitle>
          <Stack direction="row" spacing={1} alignItems="center">
            <Typography variant="h6" sx={{ flexGrow: 1 }}>
              Run #{selectedRun?.runId} - {selectedRun?.customerName}
            </Typography>
            <Button
              size="small"
              variant="contained"
              startIcon={runTier2Mutation.isPending ? <CircularProgress size={14} color="inherit" /> : <PlayArrowOutlinedIcon />}
              onClick={() => selectedRun && runTier2Mutation.mutate(selectedRun.runId)}
              disabled={!selectedRun || detailsLoading || !detailRows.length || runTier2Mutation.isPending}
            >
              Run Tier 2 Screening
            </Button>
            <Button
              size="small"
              startIcon={<DownloadOutlinedIcon />}
              onClick={() => selectedRun && void downloadReport(selectedRun.runId, "pdf")}
            >
              PDF
            </Button>
            <Button
              size="small"
              startIcon={<DownloadOutlinedIcon />}
              onClick={() => selectedRun && void downloadReport(selectedRun.runId, "excel")}
            >
              Excel
            </Button>
          </Stack>
        </DialogTitle>
        <DialogContent dividers>
          {detailsLoading ? (
            <Stack alignItems="center" sx={{ py: 4 }}>
              <CircularProgress />
            </Stack>
          ) : detailRows.length === 0 ? (
            <Alert severity="info">No vendor results found for this run.</Alert>
          ) : (
            <>
              <Box sx={{ height: 420 }}>
                <DataGrid
                  rows={detailRows}
                  columns={vendorColumns}
                  pageSizeOptions={[10, 25]}
                  disableRowSelectionOnClick
                />
              </Box>

              {tier2Query.isLoading && (
                <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 2 }}>
                  <CircularProgress size={18} />
                  <Typography variant="body2" color="text.secondary">Loading Tier 2 findings...</Typography>
                </Stack>
              )}

              {tier2Query.data && <Tier2StructuredDetails result={tier2Query.data} />}

              {tier2Query.isError && !runTier2Mutation.isPending && (
                <Alert severity="info" sx={{ mt: 2 }}>
                  Tier 2 screening has not been run for this Tier 1 run yet.
                </Alert>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </Stack>
  );
}


