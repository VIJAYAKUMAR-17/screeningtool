﻿import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import PlaylistAddOutlinedIcon from "@mui/icons-material/PlaylistAddOutlined";
import PlayCircleOutlineOutlinedIcon from "@mui/icons-material/PlayCircleOutlineOutlined";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Dialog,
  DialogContent,
  DialogTitle,
  Grid2,
  IconButton,
  Link,
  Stack,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import { DataGrid, GridColDef } from "@mui/x-data-grid";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { useFieldArray, useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { Link as RouterLink } from "react-router-dom";
import { zodResolver } from "@hookform/resolvers/zod";
import { PageTitle } from "@/components/common/PageTitle";
import { StatusChip } from "@/components/common/StatusChip";
import { api } from "@/services/api";
import { http } from "@/services/http";
import { Tier2ScreeningResult } from "@/types/api";
import { screeningFormSchema, ScreeningFormValues } from "./screeningSchema";
import { Tier2StructuredDetails } from "@/components/common/Tier2StructuredDetails";

type ScreeningResultRow = Awaited<ReturnType<typeof api.screenEntities>>["results"][number] & { id: number };
type ScreeningPageCache = {
  lastResult: Awaited<ReturnType<typeof api.screenEntities>> | null;
  tier2ByEntity: Record<string, Tier2ScreeningResult>;
  tier2LoadingByEntity: Record<string, boolean>;
  tier2ErrorByEntity: Record<string, string>;
  activeEntity: string | null;
};

const screeningPageCache: ScreeningPageCache = {
  lastResult: null,
  tier2ByEntity: {},
  tier2LoadingByEntity: {},
  tier2ErrorByEntity: {},
  activeEntity: null,
};

export function ScreeningPage() {
  const form = useForm<ScreeningFormValues>({
    resolver: zodResolver(screeningFormSchema),
    defaultValues: {
      customerName: "",
      entries: [{ companyName: "", country: "", identifier: "" }],
    },
  });

  const entriesArray = useFieldArray({ control: form.control, name: "entries" });
  const queryClient = useQueryClient();
  const [lastResult, setLastResult] = useState<Awaited<ReturnType<typeof api.screenEntities>> | null>(screeningPageCache.lastResult);
  const [tier2ByEntity, setTier2ByEntity] = useState<Record<string, Tier2ScreeningResult>>(screeningPageCache.tier2ByEntity);
  const [tier2LoadingByEntity, setTier2LoadingByEntity] = useState<Record<string, boolean>>(screeningPageCache.tier2LoadingByEntity);
  const [tier2ErrorByEntity, setTier2ErrorByEntity] = useState<Record<string, string>>(screeningPageCache.tier2ErrorByEntity);
  const [activeEntity, setActiveEntity] = useState<string | null>(screeningPageCache.activeEntity);

  useEffect(() => {
    screeningPageCache.lastResult = lastResult;
  }, [lastResult]);

  useEffect(() => {
    screeningPageCache.tier2ByEntity = tier2ByEntity;
  }, [tier2ByEntity]);

  useEffect(() => {
    screeningPageCache.tier2LoadingByEntity = tier2LoadingByEntity;
  }, [tier2LoadingByEntity]);

  useEffect(() => {
    screeningPageCache.tier2ErrorByEntity = tier2ErrorByEntity;
  }, [tier2ErrorByEntity]);

  useEffect(() => {
    screeningPageCache.activeEntity = activeEntity;
  }, [activeEntity]);

  const refreshDerivedScreens = async (runId?: number) => {
    const ops = [
      queryClient.invalidateQueries({ queryKey: ["dashboard-stats"] }),
      queryClient.invalidateQueries({ queryKey: ["dashboard-charts"] }),
      queryClient.invalidateQueries({ queryKey: ["results"] }),
      queryClient.invalidateQueries({ queryKey: ["audit-logs"] }),
      queryClient.invalidateQueries({ queryKey: ["tier2-dashboard"] }),
    ];
    if (runId) {
      ops.push(queryClient.invalidateQueries({ queryKey: ["tier2-run", runId] }));
    }
    await Promise.all(ops);
  };

  const runTier2ForEntity = async (runId: number, entityName: string) => {
    setTier2LoadingByEntity((prev) => ({ ...prev, [entityName]: true }));
    setTier2ErrorByEntity((prev) => ({ ...prev, [entityName]: "" }));

    try {
      const { data } = await http.post<Tier2ScreeningResult>(
        "/tier2/screen",
        { run_id: runId, primary_entity: entityName, include_adverse_media: true },
        { timeout: 0 },
      );
      setTier2ByEntity((prev) => ({ ...prev, [entityName]: data }));
    } catch (err) {
      setTier2ErrorByEntity((prev) => ({ ...prev, [entityName]: (err as Error).message }));
    } finally {
      setTier2LoadingByEntity((prev) => ({ ...prev, [entityName]: false }));
    }
  };

  const runAllTier2 = async (runId: number, names: string[]) => {
    const uniqueNames = Array.from(new Set(names.map((n) => n.trim()).filter(Boolean)));
    if (!uniqueNames.length) return;

    toast.loading("Tier 2 screening started for all rows", { id: "tier2-batch" });
    await Promise.all(uniqueNames.map((name) => runTier2ForEntity(runId, name)));

    const failed = uniqueNames.filter((name) => Boolean(tier2ErrorByEntity[name])).length;
    if (failed > 0) {
      toast.error(`Tier 2 completed with ${failed} issue(s). Eye icon works for successful rows.`, { id: "tier2-batch" });
    } else {
      toast.success("Tier 2 completed for all rows", { id: "tier2-batch" });
    }
  };

  const screenMutation = useMutation({
    mutationFn: api.screenEntities,
    onMutate: () => toast.loading("Tier 1 screening started", { id: "screening" }),
    onSuccess: async (data) => {
      toast.success("Tier 1 screening completed", { id: "screening" });
      setLastResult(data);
      setTier2ByEntity({});
      setTier2LoadingByEntity({});
      setTier2ErrorByEntity({});
      setActiveEntity(null);

      const names = data.results.map((r) => r.queriedName);
      await runAllTier2(data.runId, names);
      await refreshDerivedScreens(data.runId);
    },
    onError: (err) => toast.error(err.message, { id: "screening" }),
  });

  const onSubmit = form.handleSubmit((values) => {
    screenMutation.mutate({ customerName: values.customerName, entities: values.entries });
  });

  const clearResults = () => {
    setLastResult(null);
    setTier2ByEntity({});
    setTier2LoadingByEntity({});
    setTier2ErrorByEntity({});
    setActiveEntity(null);
  };

  const downloadReport = async (kind: "pdf" | "excel") => {
    if (!lastResult?.runId) {
      toast.error("Run a screening first");
      return;
    }
    const id = toast.loading(`Preparing ${kind.toUpperCase()}...`);
    try {
      await api.downloadReport(lastResult.runId, kind);
      toast.success(`${kind.toUpperCase()} downloaded`, { id });
    } catch (err) {
      toast.error((err as Error).message, { id });
    }
  };

  const resultRows: ScreeningResultRow[] = lastResult?.results.map((r, idx) => ({ ...r, id: idx + 1 })) ?? [];
  const readyCount = useMemo(() => Object.keys(tier2ByEntity).length, [tier2ByEntity]);

  const resultColumns: GridColDef<ScreeningResultRow>[] = [
    {
      field: "queriedName",
      headerName: "Name",
      flex: 1.2,
      minWidth: 200,
      renderCell: (params) => (
        <Stack direction="row" spacing={0.8} alignItems="center" sx={{ height: "100%" }}>
          <span>{params.value as string}</span>
          {params.row.resultType === "customer" && <Chip label="Customer" size="small" color="info" variant="outlined" />}
        </Stack>
      ),
    },
    { field: "status", headerName: "Status", width: 160, renderCell: (params) => <StatusChip status={params.row.status} /> },
    { field: "matchScore", headerName: "Score", width: 100, valueFormatter: (value) => (typeof value === "number" ? `${value}%` : "-") },
    { field: "matchedName", headerName: "Matched Entity", flex: 1, minWidth: 200, valueGetter: (_, row) => row.matchedName ?? "-" },
    { field: "ofacSource", headerName: "List", width: 100, valueGetter: (_, row) => row.ofacSource ?? "-" },
    { field: "matchType", headerName: "Match Type", width: 130, valueGetter: (_, row) => row.matchType ?? "-" },
    {
      field: "tier2",
      headerName: "Tier 2",
      width: 90,
      sortable: false,
      filterable: false,
      renderCell: (params) => {
        const name = params.row.queriedName;
        const loading = !!tier2LoadingByEntity[name];
        const hasResult = !!tier2ByEntity[name];
        const hasError = !!tier2ErrorByEntity[name];

        if (loading) return <CircularProgress size={18} />;

        return (
          <Tooltip title={hasResult ? "View Tier 2 details" : hasError ? tier2ErrorByEntity[name] : "Tier 2 pending"}>
            <span>
              <IconButton size="small" onClick={() => setActiveEntity(name)} disabled={!hasResult} color={hasResult ? "primary" : "default"}>
                <VisibilityOutlinedIcon fontSize="small" />
              </IconButton>
            </span>
          </Tooltip>
        );
      },
    },
  ];

  const activeTier2 = activeEntity ? tier2ByEntity[activeEntity] : null;

  return (
    <Stack spacing={2.5}>
      <PageTitle title="Screening" subtitle="Tier 1 and Tier 2 run together. Use eye icon per row to open Tier 2 details in popup." />

      <Card component={motion.div} initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <CardContent>
          <Stack component="form" spacing={2} onSubmit={onSubmit}>
            <TextField
              label="Customer Name"
              {...form.register("customerName")}
              error={!!form.formState.errors.customerName}
              helperText={form.formState.errors.customerName?.message}
            />

            {entriesArray.fields.map((field, index) => (
              <Grid2 container spacing={1.2} key={field.id} alignItems="center">
                <Grid2 size={{ xs: 12, md: 5 }}>
                  <TextField
                    fullWidth
                    label={`Company/Vendor ${index + 1}`}
                    {...form.register(`entries.${index}.companyName`)}
                    error={!!form.formState.errors.entries?.[index]?.companyName}
                    helperText={form.formState.errors.entries?.[index]?.companyName?.message}
                  />
                </Grid2>
                <Grid2 size={{ xs: 12, md: 3 }}>
                  <TextField fullWidth label="Country (Optional)" {...form.register(`entries.${index}.country`)} />
                </Grid2>
                <Grid2 size={{ xs: 10, md: 3 }}>
                  <TextField fullWidth label="Identifier (Optional)" {...form.register(`entries.${index}.identifier`)} />
                </Grid2>
                <Grid2 size={{ xs: 2, md: 1 }}>
                  <IconButton aria-label="remove entry" disabled={entriesArray.fields.length === 1} onClick={() => entriesArray.remove(index)}>
                    <DeleteOutlineOutlinedIcon />
                  </IconButton>
                </Grid2>
              </Grid2>
            ))}

            <Stack direction={{ xs: "column", sm: "row" }} spacing={1.2} alignItems="center">
              <Button startIcon={<PlaylistAddOutlinedIcon />} onClick={() => entriesArray.append({ companyName: "", country: "", identifier: "" })}>Add Another Name</Button>
              <Button color="warning" onClick={() => form.reset({ customerName: "", entries: [{ companyName: "", country: "", identifier: "" }] })}>Clear Form</Button>
              <Button color="warning" onClick={clearResults} disabled={!lastResult && Object.keys(tier2ByEntity).length === 0}>Clear All</Button>
              <Button type="submit" disabled={screenMutation.isPending} variant="contained" startIcon={<PlayCircleOutlineOutlinedIcon />}>Screen All</Button>
              <Button startIcon={<DownloadOutlinedIcon />} disabled={!lastResult} onClick={() => void downloadReport("pdf")}>Download PDF</Button>
              <Button startIcon={<DownloadOutlinedIcon />} disabled={!lastResult} onClick={() => void downloadReport("excel")}>Download Excel</Button>
              <Typography variant="body2" color="text.secondary" sx={{ ml: "auto !important" }}>
                Have a long list? <Link component={RouterLink} to="/bulk-screening" underline="hover">Use Bulk Screening</Link>
              </Typography>
            </Stack>
          </Stack>
        </CardContent>
      </Card>

      {lastResult && (
        <Card component={motion.div} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 1.5 }}>Tier 1 Results</Typography>
            <Alert severity="info" sx={{ mb: 2 }}>
              Run {lastResult.runId} completed in {lastResult.elapsedSeconds.toFixed(2)}s. Tier 2 ready for {readyCount}/{resultRows.length} rows. Click the eye icon to view details.
            </Alert>
            <Box sx={{ height: 420 }}>
              <DataGrid rows={resultRows} columns={resultColumns} pageSizeOptions={[10, 25, 50]} disableRowSelectionOnClick />
            </Box>
          </CardContent>
        </Card>
      )}

      <Dialog open={Boolean(activeTier2)} onClose={() => setActiveEntity(null)} maxWidth="lg" fullWidth>
        <DialogTitle>Tier 2 Investigation Details</DialogTitle>
        <DialogContent dividers>
          {activeEntity && activeTier2 && <Tier2StructuredDetails entityName={activeEntity} result={activeTier2} />}
        </DialogContent>
      </Dialog>
    </Stack>
  );
}



