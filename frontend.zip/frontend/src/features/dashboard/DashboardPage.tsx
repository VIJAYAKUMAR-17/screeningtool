import { Card, CardContent, Grid2, Skeleton, Stack, Typography } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { format, parseISO } from "date-fns";
import { motion } from "framer-motion";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PageTitle } from "@/components/common/PageTitle";
import { api } from "@/services/api";

const chartColors = ["#22a06b", "#c77700", "#d14343", "#0b5ed7"];

const renderPieLabel = ({
  name,
  value,
  percent,
}: {
  name: string;
  value: number;
  percent: number;
}) => (percent > 0.04 && value > 0 ? `${name}: ${value}` : "");

function KpiCard({ label, value }: { label: string; value: number }) {
  return (
    <Card
      component={motion.div}
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
      sx={{ border: 1, borderColor: "divider", bgcolor: (theme) => theme.palette.glass.background, backdropFilter: "blur(8px)" }}
    >
      <CardContent>
        <Typography variant="body2" color="text.secondary">
          {label}
        </Typography>
        <Typography variant="h5">{value.toLocaleString()}</Typography>
      </CardContent>
    </Card>
  );
}

export function DashboardPage() {
  const stats = useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: api.getDashboardStats,
    refetchOnMount: "always",
    refetchOnWindowFocus: true,
    refetchInterval: 15000,
  });
  const charts = useQuery({
    queryKey: ["dashboard-charts"],
    queryFn: api.getDashboardCharts,
    refetchOnMount: "always",
    refetchOnWindowFocus: true,
    refetchInterval: 15000,
  });

  const loading = stats.isLoading || charts.isLoading;

  return (
    <Stack spacing={2.5}>
      <PageTitle title="Compliance Dashboard" subtitle="Operational overview of sanctions screening performance." />

      <Grid2 container spacing={2}>
        <Grid2 size={{ xs: 12, sm: 6, lg: 3 }}>
          <KpiCard label="Total Screenings" value={stats.data?.totalScreenings ?? 0} />
        </Grid2>
        <Grid2 size={{ xs: 12, sm: 6, lg: 3 }}>
          <KpiCard label="Matches Found" value={stats.data?.matchesFound ?? 0} />
        </Grid2>
        <Grid2 size={{ xs: 12, sm: 6, lg: 3 }}>
          <KpiCard label="Cleared Results" value={stats.data?.clearedResults ?? 0} />
        </Grid2>
        <Grid2 size={{ xs: 12, sm: 6, lg: 3 }}>
          <KpiCard label="Pending Reviews" value={stats.data?.pendingReviews ?? 0} />
        </Grid2>
      </Grid2>

      <Grid2 container spacing={2}>
        <Grid2 size={{ xs: 12, lg: 7 }}>
          <Card sx={{ p: 2, height: 360 }}>
            <Typography variant="h6" sx={{ mb: 1.5 }}>
              Screening Trends
            </Typography>
            {loading ? (
              <Skeleton variant="rounded" height={280} />
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={charts.data?.trend} barCategoryGap="35%">
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis
                    dataKey="date"
                    tickFormatter={(v: string) => {
                      try { return format(parseISO(v), "MMM d"); } catch { return v; }
                    }}
                    tick={{ fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis allowDecimals={false} axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                  <Tooltip
                    formatter={(value, name) => [value, name === "screenings" ? "Vendors Screened" : "Flagged"]}
                    labelFormatter={(label: string) => {
                      try { return format(parseISO(label), "MMM d, yyyy"); } catch { return label; }
                    }}
                  />
                  <Legend formatter={(value) => value === "screenings" ? "Vendors Screened" : "Flagged"} />
                  <Bar dataKey="screenings" name="screenings" fill="#0b5ed7" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="matches" name="matches" fill="#d14343" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </Card>
        </Grid2>

        <Grid2 size={{ xs: 12, lg: 5 }}>
          <Card sx={{ p: 2, height: 360 }}>
            <Typography variant="h6" sx={{ mb: 1.5 }}>
              Match Distribution
            </Typography>
            {loading ? (
              <Skeleton variant="rounded" height={280} />
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <PieChart>
                  <Pie
                    data={charts.data?.matchDistribution}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={52}
                    outerRadius={96}
                    paddingAngle={3}
                    label={renderPieLabel}
                    labelLine={{ stroke: "#888", strokeWidth: 1 }}
                  >
                    {(charts.data?.matchDistribution ?? []).map((_, idx) => (
                      <Cell key={idx} fill={chartColors[idx % chartColors.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value, name) => [value, name]} />
                  <Legend
                    formatter={(value, entry) =>
                      `${value}: ${(entry.payload as { value: number }).value}`
                    }
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </Card>
        </Grid2>
      </Grid2>
    </Stack>
  );
}
